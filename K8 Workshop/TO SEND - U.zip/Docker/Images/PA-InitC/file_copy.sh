#!/bin/bash

file="/data/db.sqlite3"
if [ ! -f "$file" ]
then
    cp /opt/data/db.sqlite3 /data/
    echo "Copying data file"
fi
