from django.apps import AppConfig


class BrowserConfig(AppConfig):
    name = 'browser'
