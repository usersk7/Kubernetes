from django.db import models

# Create your models here.
class HitCount(models.Model):
    hit_from_id = models.CharField(max_length=1000)
    hit_from_app = models.CharField(max_length=50)

