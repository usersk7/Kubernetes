from django.apps import AppConfig


class HitcountConfig(AppConfig):
    name = 'hitcount'
