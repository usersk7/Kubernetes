import os
import socket
from django.http import HttpResponse
from rest_framework.decorators import api_view # new
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import authentication_classes, permission_classes

from .models import HitCount

# Create your views here.
def hit_and_get_views(request):
    all_objects = HitCount.objects.all()
    number_of_hits = 1
    from_same_app = 1
    from_same_host = 1

    env_host = os.environ.get('MY_POD_ID', None)
    env_node = os.environ.get('MY_POD_NODE', None)
    env_hostname = None
    if env_host is not None and env_node is not None:
        env_hostname = env_host+env_node

    hostname = env_hostname if env_hostname else socket.gethostname()

    for hit in all_objects:
        number_of_hits += 1
        if hit.hit_from_id == hostname:
            from_same_host += 1
        if hit.hit_from_app == 'primary_app':
            from_same_app += 1

    HitCount.objects.create(hit_from_id=hostname, hit_from_app='primary_app')

    return HttpResponse("Number of Total Hit Now: {0}<br>From App '{3}': {4}<br>From Host '{1}': {2}<br>".format(number_of_hits, hostname, from_same_host, 'primary_app', from_same_app))


@api_view(['POST'])
@authentication_classes((BasicAuthentication, ))
@permission_classes((IsAuthenticated,))
def api_hit(request):
    all_objects = HitCount.objects.all()
    number_of_hits = 1
    from_same_app = 1
    from_same_host = 1
    hit_from_id = request.data['id']
    hit_from_app = request.data['app_name']

    for hit in all_objects:
        number_of_hits += 1
        if hit.hit_from_id == hit_from_id:
            from_same_host += 1
        if hit.hit_from_app == hit_from_app:
            from_same_app += 1

    HitCount.objects.create(hit_from_id=hit_from_id, hit_from_app=hit_from_app)

    return Response(status=status.HTTP_200_OK, data={'number_of_total_hits': number_of_hits, 'from_same_app': from_same_app, 'from_same_host': from_same_host})
