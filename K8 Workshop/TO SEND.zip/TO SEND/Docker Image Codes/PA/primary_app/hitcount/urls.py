from django.urls import path
from . import views

urlpatterns = [
    path(r'hit/', views.hit_and_get_views),
    path(r'api/hit/', views.api_hit),
]
