import json
import os
import requests
import socket
from django.http import HttpResponse

# Create your views here.
def hit_and_get_views(request):
    primary_app_host = os.environ['PRIMARY_APP_HOST']
    primary_app_port = os.environ['PRIMARY_APP_PORT']
    primary_app_user = os.environ['PRIMARY_APP_USER']
    primary_app_pass = os.environ['PRIMARY_APP_PASS']

    app_name = 'secondary_app'
    env_host = os.environ.get('MY_POD_ID', None)
    env_node = os.environ.get('MY_POD_NODE', None)
    env_hostname = None
    if env_host is not None and env_node is not None:
        env_hostname = env_host+env_node

    hostname = env_hostname if env_hostname else socket.gethostname()

    response = requests.post("http://{0}:{1}/api/hit/".format(primary_app_host, primary_app_port), 
            headers = {"Content-Type": "application/json"}, auth=((primary_app_user, primary_app_pass)), json={'id': hostname, 'app_name': app_name})

    if response.status_code==200:
        data = json.loads(response.content)
        total = data['number_of_total_hits']
        app = data['from_same_app']
        host = data['from_same_host']
        return HttpResponse("Number of Total Hit Now: {0}<br>From App '{3}': {4}<br>From Host '{1}': {2}<br>".format(total, hostname, host, 'secondary_app', app))
    else:
        return HttpResponse("Error Code: {0}".format(response.status_code))

